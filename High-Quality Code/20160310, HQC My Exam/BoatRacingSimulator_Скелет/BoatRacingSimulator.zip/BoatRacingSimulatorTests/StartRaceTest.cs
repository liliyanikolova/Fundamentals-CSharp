﻿namespace BoatRacingSimulatorTests
{
    using BoatRacingSimulator.Controllers;
    using BoatRacingSimulator.Interfaces;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public class StartRaceTest
    {
        private IBoatSimulatorController Contoller { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            this.Contoller = new BoatSimulatorController();
        }

        [TestMethod]
        public void StartRace_WithCorrectInput_ShouldReturnSuccessMessage()
        {
            var race = this.Contoller.OpenRace(1500, 150, 10, false);
        }
    }
}
